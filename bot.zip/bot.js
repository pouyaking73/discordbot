const { Client, GatewayIntentBits } = require("discord.js");

// ---------- تابع تبدیل یوزرنیم با شیفت ۳تایی ----------
function shiftUsername(str) {
  const letters = "abcdefghijklmnopqrstuvwxyz";
  const lettersUp = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const numbers = "0123456789";

  let result = "";

  for (let char of str) {
    if (letters.includes(char)) {
      const index = letters.indexOf(char);
      const newIndex = (index + 3) % 26;
      result += letters[newIndex];
    } else if (lettersUp.includes(char)) {
      const index = lettersUp.indexOf(char);
      const newIndex = (index + 3) % 26;
      result += lettersUp[newIndex];
    } else if (numbers.includes(char)) {
      const index = numbers.indexOf(char);
      const newIndex = (index + 3) % 10;
      result += numbers[newIndex];
    } else {
      result += char;
    }
  }

  return result;
}

// ---------- شروع ربات ----------
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers
  ]
});

// ربات آنلاین شد
client.once("ready", () => {
  console.log(`🤖 Logged in as ${client.user.tag}`);
});

// وقتی کاربر جدید وارد سرور می‌شود
client.on("guildMemberAdd", async (member) => {

  // محاسبه مدت عضویت قبلی در سرور
  const now = Date.now();
  const joinedAt = member.joinedAt ? member.joinedAt.getTime() : null;

  // اگر joinedAt موجود نبود (به ندرت)، پیام نده
  if (!joinedAt) return;

  const diffDays = (now - joinedAt) / (1000 * 60 * 60 * 24);

  // اگر بیشتر از ۳۰ روز از عضویت قبلی کاربر گذشته، پیام نده
  if (diffDays > 30) {
    console.log(`⛔ ${member.user.tag} قبلاً عضو بوده و بیش از ۳۰ روز گذشته. پیام ارسال نشد.`);
    return;
  }

  // ---- اگر مجاز است (کمتر از ۳۰ روز) ----

  const originalUsername = member.user.username;
  const encodedUsername = shiftUsername(originalUsername);
  const safeName = encodeURIComponent(encodedUsername);

  const link = `https://shop-venturestorms.ir/dc/?dc=${safeName}`;

  const message = 
`سلام! 🙌
به سرور ونچراستورم خوش اومدی 🌟

این لینک اختصاصی شماست:
🔗 ${link}

اگر سوالی داشتی همینجا پیام بده ❤️`;

  try {
    await member.send(message);
    console.log(`📨 DM sent to: ${member.user.tag}`);
  } catch (err) {
    console.log(`🔒 نمی‌توانم DM ارسال کنم به ${member.user.tag}`);
  }
});

client.login(process.env.TOKEN);
